<?php

$_POST['data'] = '{"email":"odry.attila@keri.mako.hu","password":"1234Aa"}';
require_once('./login.php');
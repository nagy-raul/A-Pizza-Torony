<?php
$result = array(
	"data"  => null,
	"error" => null
);
$result['error'] = "REGISTER Under construction!";
$result = json_encode($result);
echo $result;